package com.umonitoring.api;

public interface OnServidorDetectado {
    void onDetectado();
}
